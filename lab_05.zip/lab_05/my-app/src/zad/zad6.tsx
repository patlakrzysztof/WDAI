// zad 6
import CounterEff from "../components/efekty/LicznikEff";
import Countdown from "../components/efekty/Odliczanie";
import Title from "../components/efekty/Tytul";

function Zad6() {
  return (
    <div>
      <CounterEff />
      <Title />
      <Countdown />
    </div>
  );
}

export default Zad6;
