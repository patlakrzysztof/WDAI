// zad 2
import Counter from "../components/liczniki/Licznik";
import NewCounter from "../components/liczniki/NowyLicznik";

function Zad2() {
  return (
    <div>
      <Counter />
      <NewCounter />
    </div>
  );
}

export default Zad2;
