// zad 1
import ShoppingCart from "../components/koszyk/Koszyk";
import NewShoppingCart from "../components/koszyk/NowyKoszyk";

function Zad1() {
  return (
    <div>
      <ShoppingCart />
      <NewShoppingCart />
    </div>
  );
}

export default Zad1;
