// zad7
import UserComment from "../components/produkty/Komentarz";
import UserComments from "../components/produkty/Komentarze";

function Zad7() {
  return (
    <div>
      <UserComments />
    </div>
  );
}

export default Zad7;
