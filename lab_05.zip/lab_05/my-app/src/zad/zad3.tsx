import Form from "../components/formularze/Formularz";
import Password from "../components/formularze/Haslo";
import Login from "../components/formularze/Logowanie";

function Zad3() {
  return (
    <div>
      <Form />
      <Password />
      <Login />
    </div>
  );
}

export default Zad3;
