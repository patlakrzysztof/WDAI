// zad 4
import Update from "../components/inne/Aktualizacja";
import Ternary from "../components/inne/Ternary";

function Zad4() {
  return (
    <div>
      <Ternary />
      <Update />
    </div>
  );
}

export default Zad4;
