// zad 5
import Students from "../components/studenci/Studenci";
import StudentManager from "../components/studenci/StudentManager";

function Zad5() {
  return (
    <div>
      <Students />
      <StudentManager />
    </div>
  );
}

export default Zad5;
